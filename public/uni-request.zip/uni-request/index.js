

import request from './src/request';

export default request;


